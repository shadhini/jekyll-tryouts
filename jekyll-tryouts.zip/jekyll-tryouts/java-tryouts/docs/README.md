# Java Tryouts Docs

## To build static site 
```shell
bundle exec jekyll build
```
* Static site is built in `_site` directory

## To deploy in production environment 
```shell
JEKYLL_ENV=production bundle exec jekyll build
```
