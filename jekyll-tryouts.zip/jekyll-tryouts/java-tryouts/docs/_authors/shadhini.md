---
short_name: shadhini
name: Shadhini Jayatilake
position: Computer Science Engineer / Software Engineer
---

A computer science & software engineering enthusiast.