---
short_name: basics
name: Java Basics
---

Basics of Java programming language.