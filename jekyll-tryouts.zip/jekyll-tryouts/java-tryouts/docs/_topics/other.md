---
short_name: other
name: Other
---

Announcements and other information will be posted here. Mostly, this collection will be used for announcements and 
other information that doesn't fit into other categories.