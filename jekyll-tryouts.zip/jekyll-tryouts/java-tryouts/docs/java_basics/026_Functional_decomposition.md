# Functional decomposition
The approach of dividing a complex program into subroutines