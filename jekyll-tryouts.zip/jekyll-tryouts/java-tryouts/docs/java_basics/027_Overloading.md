# Overloading
`Method overloading`; a programming concept that allows you to 
design numerous methods that share the `same name but have distinct arguments`. 
* When a method is called, the language determines which version of the method to run based on 
  * the number, 
  * types, and 
  * order of the arguments given. 
* Allows creating code that is more concise and easier to understand while still handling all sorts of inputs.

==> you can invoke different methods by the same name by passing different arguments.

```
method signature (unique identifier for a method) == method's name + its argument types
```

```java
// Method Overloading
public static int abs(int a) { return (a < 0) ? -a : a; }

public static float abs(float a) { return (a <= 0.0F) ? 0.0F - a : a; }
```

```java
// compilation error abs(int) is already defined
// Despite the fact that the methods have different return types, their signatures are identical
public static int abs(int a) { return (a < 0) ? -a : a; } // abs(int) is already defined

public static float abs(int a) { return (a < 0.0F) ? 0.0F - a : a; } // abs(int) is already defined
```
```java
// Method overloading with same type of parameters but different orders
public static void print(String stringToPrint) {
    System.out.println(stringToPrint);
}

public static void print(String stringToPrint, int times) {
    for (int i = 0; i < times; i++) {
        System.out.println(stringToPrint);
    }
}

public static void print(int times, String stringToPrint) {
    for (int i = 0; i < times; i++) {
        System.out.println(stringToPrint);
    }
}

public static void print(int val) {
    System.out.println(val);
}
```

## Overloading and casting

```java
public class OverloadingExample {

    public static void print(short a) {
        System.out.println("short arg: " + a);
    }

    public static void print(int a) {
        System.out.println("int arg: " + a);
    }

    public static void print(long a) {
        System.out.println("long arg: " + a);
    }

    public static void print(double a) {
        System.out.println("double arg: " + a);
    }

    public static void main(String[] args) {
        print(100);
    }
}
// OUTPUT
int arg: 100
```

In the case where the `method parameter type is not exactly the same as the type of the passed argument`, 

==> the compiler chooses the method that has the closest argument type in order of `implicit casting`.

```java
 public class OverloadingExample {

    public static void print(short a) {
        System.out.println("short arg: " + a);
    }

    public static void main(String[] args) {
        print((short) 100);  // explicit casting 
    }
}
```
In this case, `100` is treated as an `int` by default and JVM doesn't know if the passed value can be cast to `short` safely. 

==> So, the only way to pass the short argument is by casting the value `explicitly`.