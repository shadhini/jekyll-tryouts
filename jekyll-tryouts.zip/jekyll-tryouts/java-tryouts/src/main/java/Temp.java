import java.util.Arrays;
import java.util.Scanner;

public class Temp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        System.out.println(--a);


//        System.out.println(solution2(1041));
//
//        int[] bag1 = {1, 2, 3};
//        int[] bag2 = {2, 1, 3};
//        System.out.println(isEqual(bag1, bag2));
    }


    static boolean isEqual(int[] bag1, int[] bag2) {
        //    Tests:
//            [1,2,3], [2,1,3] -> true
//            [2,1,2,3], [2,2,1,3] -> true
//            [1,2,3], [2,2,1] -> false
//            [1,2,3], [1,2] -> false

        if (bag1.length != bag2.length) {
            return false;
        }
        Arrays.sort(bag1);
        Arrays.sort(bag2);

        for (int i = 0; i < bag1.length; i++) {
            if (bag1[i] != bag2[i]) {
                return false;
            }
        }

        return true;

//        Set<Integer> set1 = new HashSet<>();
//        Set<Integer> set2 = new HashSet<>();
//        for (int num: bag1) {
//            set1.add(num);
//        }
//        for (int num: bag2) {
//            set2.add(num);
//        }
//        set1.removeAll(set2);
//        set1.remove()
//        if (set1.isEmpty()){
//            return true;
//        }
//        return false;
    }




    public static int solution2(int N) {
        String binaryString = Integer.toBinaryString(N);
        int maxCount = 0;
        int curCount = 0;
        int i = 1;
        char prevChar;
        char curChar;
        if (binaryString.length() >= 2) {
            while (i < binaryString.length()) {
                prevChar = binaryString.charAt(i - 1);
                curChar = binaryString.charAt(i);
                if (prevChar == '1') {
                    if (curChar == '0') {
//                        System.out.println("here");
                        i += 1;
                        curCount += 1;
//                        System.out.println("a " + i + " " + curCount);
                        while (i < binaryString.length() && curChar == '0') {
                            prevChar = binaryString.charAt(i - 1);
                            curChar = binaryString.charAt(i);
                            i += 1;
                            curCount += 1;
//                            System.out.println("b " + i + " " + curCount);
                        }
                        if (i <= binaryString.length() && curChar == '1') {
//                            System.out.println("here2 " + i);
                            if (curCount > maxCount) {
//                                System.out.println(curCount);
                                maxCount = curCount - 1;
                            }
                        } else {
                            break;
                        }
                        curCount = 0;
                    } else {
                        i += 1;
                    }
                } else {
                    i += 1;
                }
            }
        }

        return maxCount;
    }
}
