package basics;

/**
 * Type Casting
 */
public class TypeCasting {

    public static void main(String[] args) {
        // Implicit
        int num = 100;
        long bigNum = num; // 100L

        long bigNum2 = 100_000_000L;
        double bigFraction = bigNum2; // 100000000.0

        char ch = '?';
        int code = ch; // 63


    }
}
